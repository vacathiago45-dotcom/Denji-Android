import React, { useState } from 'react';
import { Check, Copy, Terminal } from 'lucide-react';

interface MarkdownRendererProps {
  content: string;
  isStreaming?: boolean;
}

export const MarkdownRenderer: React.FC<MarkdownRendererProps> = ({ content, isStreaming }) => {
  return (
    <div className="text-zinc-100 text-[15px] leading-relaxed space-y-3 font-sans break-words">
      {renderBlocks(content)}
      {isStreaming && (
        <span className="inline-block w-2 h-4 ml-1 bg-amber-400 animate-pulse align-middle" />
      )}
    </div>
  );
};

function renderBlocks(raw: string) {
  if (!raw) return null;

  // Split content by triple backticks for code blocks
  const parts = raw.split(/(```[\s\S]*?```)/g);

  return parts.map((part, index) => {
    if (part.startsWith('```') && part.endsWith('```')) {
      const match = part.match(/^```([a-zA-Z0-9_-]*)\n([\s\S]*?)```$/);
      const language = match ? match[1] || 'plaintext' : 'plaintext';
      const code = match ? match[2] : part.slice(3, -3);
      return <CodeBlock key={index} code={code} language={language} />;
    }

    // Split regular text into paragraphs or list blocks
    const lines = part.split('\n');
    const elements: React.ReactNode[] = [];
    let currentList: { type: 'ul' | 'ol'; items: string[] } | null = null;
    let quoteLines: string[] = [];

    const flushList = () => {
      if (currentList) {
        if (currentList.type === 'ul') {
          elements.push(
            <ul key={`ul-${elements.length}`} className="my-2.5 ml-4 space-y-1.5 list-disc marker:text-amber-400">
              {currentList.items.map((item, i) => (
                <li key={i}>{formatInline(item)}</li>
              ))}
            </ul>
          );
        } else {
          elements.push(
            <ol key={`ol-${elements.length}`} className="my-2.5 ml-4 space-y-1.5 list-decimal marker:text-amber-400">
              {currentList.items.map((item, i) => (
                <li key={i}>{formatInline(item)}</li>
              ))}
            </ol>
          );
        }
        currentList = null;
      }
    };

    const flushQuote = () => {
      if (quoteLines.length > 0) {
        elements.push(
          <blockquote
            key={`quote-${elements.length}`}
            className="my-3 pl-3.5 py-1 border-l-2 border-amber-500 bg-amber-500/5 text-zinc-300 italic rounded-r"
          >
            {quoteLines.map((line, i) => (
              <p key={i}>{formatInline(line)}</p>
            ))}
          </blockquote>
        );
        quoteLines = [];
      }
    };

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];

      // Blockquotes
      if (line.startsWith('>')) {
        flushList();
        quoteLines.push(line.replace(/^>\s?/, ''));
        continue;
      } else {
        flushQuote();
      }

      // Headers
      if (line.startsWith('### ')) {
        flushList();
        elements.push(
          <h3 key={`h3-${i}`} className="text-base font-semibold text-amber-200 mt-4 mb-1">
            {formatInline(line.replace('### ', ''))}
          </h3>
        );
        continue;
      }
      if (line.startsWith('## ')) {
        flushList();
        elements.push(
          <h2 key={`h2-${i}`} className="text-lg font-bold text-amber-300 mt-5 mb-1.5 pb-1 border-b border-zinc-800">
            {formatInline(line.replace('## ', ''))}
          </h2>
        );
        continue;
      }
      if (line.startsWith('# ')) {
        flushList();
        elements.push(
          <h1 key={`h1-${i}`} className="text-xl font-extrabold text-amber-400 mt-5 mb-2 pb-1 border-b border-zinc-800">
            {formatInline(line.replace('# ', ''))}
          </h1>
        );
        continue;
      }

      // Horizontal rule
      if (/^(\*\*\*|---|___)$/.test(line.trim())) {
        flushList();
        elements.push(<hr key={`hr-${i}`} className="my-4 border-zinc-800" />);
        continue;
      }

      // Unordered list
      const ulMatch = line.match(/^(\s*)[-*+]\s+(.*)$/);
      if (ulMatch) {
        if (!currentList || currentList.type !== 'ul') {
          flushList();
          currentList = { type: 'ul', items: [] };
        }
        currentList.items.push(ulMatch[2]);
        continue;
      }

      // Ordered list
      const olMatch = line.match(/^(\s*)\d+\.\s+(.*)$/);
      if (olMatch) {
        if (!currentList || currentList.type !== 'ol') {
          flushList();
          currentList = { type: 'ol', items: [] };
        }
        currentList.items.push(olMatch[2]);
        continue;
      }

      flushList();

      if (line.trim() === '') {
        // Empty line separator
        continue;
      }

      elements.push(
        <p key={`p-${i}`} className="my-1.5 leading-relaxed">
          {formatInline(line)}
        </p>
      );
    }

    flushList();
    flushQuote();

    return <React.Fragment key={index}>{elements}</React.Fragment>;
  });
}

function formatInline(text: string): React.ReactNode {
  // Regex to match inline code, bold, italic
  const parts: React.ReactNode[] = [];
  let remaining = text;
  let keyIndex = 0;

  while (remaining.length > 0) {
    // Inline code `...`
    const codeMatch = remaining.match(/^(.*?)`([^`]+)`(.*)$/s);
    // Bold **...**
    const boldMatch = remaining.match(/^(.*?)\*\*([^*]+)\*\*(.*)$/s);
    // Italic *...*
    const italicMatch = remaining.match(/^(.*?)\*([^*]+)\*(.*)$/s);

    const matches = [
      codeMatch ? { type: 'code', index: codeMatch[1].length, match: codeMatch } : null,
      boldMatch ? { type: 'bold', index: boldMatch[1].length, match: boldMatch } : null,
      italicMatch ? { type: 'italic', index: italicMatch[1].length, match: italicMatch } : null,
    ].filter(Boolean) as { type: string; index: number; match: RegExpMatchArray }[];

    if (matches.length === 0) {
      parts.push(remaining);
      break;
    }

    // Pick first match by lowest index
    matches.sort((a, b) => a.index - b.index);
    const first = matches[0];

    // Push leading plain text
    if (first.index > 0) {
      parts.push(first.match[1]);
    }

    if (first.type === 'code') {
      parts.push(
        <code
          key={`code-${keyIndex++}`}
          className="px-1.5 py-0.5 mx-0.5 rounded bg-zinc-800 text-amber-300 font-mono text-[13px] border border-zinc-700/60"
        >
          {first.match[2]}
        </code>
      );
    } else if (first.type === 'bold') {
      parts.push(
        <strong key={`bold-${keyIndex++}`} className="font-semibold text-amber-200/90">
          {formatInline(first.match[2])}
        </strong>
      );
    } else if (first.type === 'italic') {
      parts.push(
        <em key={`italic-${keyIndex++}`} className="italic text-zinc-300">
          {formatInline(first.match[2])}
        </em>
      );
    }

    remaining = first.match[3];
  }

  return <>{parts}</>;
}

const CodeBlock: React.FC<{ code: string; language: string }> = ({ code, language }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // fallback
    }
  };

  return (
    <div className="my-3 rounded-lg overflow-hidden border border-zinc-750 bg-zinc-950 font-mono text-xs shadow-md">
      <div className="flex items-center justify-between px-3.5 py-1.5 bg-zinc-900 border-b border-zinc-800 text-zinc-400">
        <div className="flex items-center gap-1.5 text-[11px] font-medium tracking-wide">
          <Terminal className="w-3.5 h-3.5 text-amber-400" />
          <span>{language || 'code'}</span>
        </div>
        <button
          onClick={handleCopy}
          className="flex items-center gap-1 text-[11px] hover:text-zinc-200 transition-colors px-1.5 py-0.5 rounded hover:bg-zinc-800"
          title="Copiar código"
        >
          {copied ? (
            <>
              <Check className="w-3 h-3 text-emerald-400" />
              <span className="text-emerald-400">Copiado</span>
            </>
          ) : (
            <>
              <Copy className="w-3 h-3" />
              <span>Copiar</span>
            </>
          )}
        </button>
      </div>
      <pre className="p-3.5 overflow-x-auto text-zinc-200 leading-normal text-[13px]">
        <code>{code}</code>
      </pre>
    </div>
  );
};
