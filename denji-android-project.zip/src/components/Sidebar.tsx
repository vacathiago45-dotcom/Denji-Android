import React, { useState } from 'react';
import {
  MessageSquare,
  Plus,
  Trash2,
  Edit2,
  Check,
  BookOpen,
  Code2,
  Bot,
  Coffee,
  Sparkles,
  PanelLeftClose,
  Zap,
  Download,
} from 'lucide-react';
import { ChatSession } from '../types';

interface SidebarProps {
  sessions: ChatSession[];
  activeSessionId: string;
  onSelectSession: (id: string) => void;
  onNewSession: () => void;
  onDeleteSession: (id: string) => void;
  onRenameSession: (id: string, newTitle: string) => void;
  isOpen: boolean;
  onToggleOpen: () => void;
  onOpenMangaModal: () => void;
  hasMangaContext: boolean;
}

export const Sidebar: React.FC<SidebarProps> = ({
  sessions,
  activeSessionId,
  onSelectSession,
  onNewSession,
  onDeleteSession,
  onRenameSession,
  isOpen,
  onToggleOpen,
  onOpenMangaModal,
  hasMangaContext,
}) => {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const [filterCategory, setFilterCategory] = useState<string>('all');

  const startEditing = (s: ChatSession, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingId(s.id);
    setEditTitle(s.title);
  };

  const saveEditing = (id: string, e: React.MouseEvent | React.FormEvent) => {
    e.stopPropagation();
    e.preventDefault();
    if (editTitle.trim()) {
      onRenameSession(id, editTitle.trim());
    }
    setEditingId(null);
  };

  const filteredSessions = sessions.filter((s) => {
    if (filterCategory === 'all') return true;
    return s.category === filterCategory;
  });

  return (
    <>
      {/* Mobile backdrop */}
      {isOpen && (
        <div
          onClick={onToggleOpen}
          className="fixed inset-0 z-40 bg-black/60 backdrop-blur-xs md:hidden"
        />
      )}

      <aside
        className={`fixed md:static inset-y-0 left-0 z-40 w-72 flex flex-col bg-zinc-950 border-r border-zinc-800/80 transition-transform duration-300 ease-in-out ${
          isOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'
        }`}
      >
        {/* Top Header: Denji Profile */}
        <div className="p-4 border-b border-zinc-800/80 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="w-10 h-10 rounded-xl bg-linear-to-br from-amber-500 to-amber-700 flex items-center justify-center text-zinc-950 font-black text-lg shadow-md shadow-amber-500/20">
                D
              </div>
              <span
                className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-emerald-500 border-2 border-zinc-950"
                title="Denji conectado"
              />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-zinc-100 text-sm tracking-wide">Denji</span>
                <span className="text-[10px] px-1.5 py-0.2 rounded bg-amber-500/10 text-amber-400 font-semibold border border-amber-500/20">
                  Gemini
                </span>
              </div>
              <p className="text-xs text-zinc-400 font-medium">Asistente personal</p>
            </div>
          </div>
          <button
            onClick={onToggleOpen}
            className="md:hidden p-1.5 rounded-lg text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800"
          >
            <PanelLeftClose className="w-5 h-5" />
          </button>
        </div>

        {/* Action Button: Nuevo Chat */}
        <div className="p-3 space-y-2">
          <button
            onClick={onNewSession}
            className="w-full flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-semibold text-sm transition shadow-sm shadow-amber-500/20 active:scale-[0.99]"
          >
            <Plus className="w-4 h-4 stroke-[2.5]" />
            <span>Nuevo Chat</span>
          </button>

          {/* Manga Project Quick Drawer Button */}
          <button
            onClick={onOpenMangaModal}
            className={`w-full flex items-center justify-between py-2 px-3 rounded-xl border text-xs font-medium transition ${
              hasMangaContext
                ? 'bg-zinc-900 border-amber-500/40 text-amber-300 hover:bg-zinc-850'
                : 'bg-zinc-900/60 border-zinc-800 text-zinc-300 hover:bg-zinc-850 hover:text-zinc-100'
            }`}
          >
            <div className="flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-amber-400" />
              <span>Proyecto Manga</span>
            </div>
            {hasMangaContext ? (
              <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
            ) : (
              <span className="text-[10px] text-zinc-400">Configurar</span>
            )}
          </button>
        </div>

        {/* Category Filter Chips */}
        <div className="px-3 py-1 flex items-center gap-1 overflow-x-auto text-[11px] scrollbar-none border-b border-zinc-900 pb-2.5">
          {[
            { id: 'all', label: 'Todos', icon: Sparkles },
            { id: 'manga', label: 'Manga', icon: BookOpen },
            { id: 'coding', label: 'Código', icon: Code2 },
            { id: 'ai', label: 'IA', icon: Bot },
            { id: 'general', label: 'Chill', icon: Coffee },
          ].map((cat) => {
            const Icon = cat.icon;
            const isActive = filterCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setFilterCategory(cat.id)}
                className={`flex items-center gap-1 px-2.5 py-1 rounded-lg shrink-0 transition font-medium ${
                  isActive
                    ? 'bg-zinc-800 text-amber-300 border border-zinc-700'
                    : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900'
                }`}
              >
                <Icon className="w-3 h-3" />
                <span>{cat.label}</span>
              </button>
            );
          })}
        </div>

        {/* Sessions List */}
        <div className="flex-1 overflow-y-auto px-2 py-2 space-y-1">
          {filteredSessions.length === 0 ? (
            <div className="p-4 text-center text-xs text-zinc-400">
              No hay chats en esta sección.
            </div>
          ) : (
            filteredSessions.map((s) => {
              const isActive = s.id === activeSessionId;
              const isEditing = editingId === s.id;

              return (
                <div
                  key={s.id}
                  onClick={() => onSelectSession(s.id)}
                  className={`group relative flex items-center justify-between p-2.5 rounded-xl text-xs cursor-pointer transition ${
                    isActive
                      ? 'bg-zinc-850 text-zinc-100 font-medium border border-zinc-700/60 shadow-inner'
                      : 'text-zinc-400 hover:bg-zinc-900/80 hover:text-zinc-200'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0 flex-1 pr-2">
                    <MessageSquare
                      className={`w-3.5 h-3.5 shrink-0 ${
                        isActive ? 'text-amber-400' : 'text-zinc-400 group-hover:text-zinc-400'
                      }`}
                    />
                    {isEditing ? (
                      <form
                        onSubmit={(e) => saveEditing(s.id, e)}
                        className="flex-1 flex items-center gap-1"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <input
                          type="text"
                          autoFocus
                          value={editTitle}
                          onChange={(e) => setEditTitle(e.target.value)}
                          onBlur={(e) => saveEditing(s.id, e)}
                          className="w-full bg-zinc-950 px-2 py-0.5 rounded border border-amber-500 text-zinc-100 text-xs focus:outline-hidden"
                        />
                        <button
                          type="button"
                          onClick={(e) => saveEditing(s.id, e)}
                          className="p-1 hover:text-amber-400"
                        >
                          <Check className="w-3 h-3" />
                        </button>
                      </form>
                    ) : (
                      <span className="truncate">{s.title || 'Conversación'}</span>
                    )}
                  </div>

                  {!isEditing && (
                    <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button
                        onClick={(e) => startEditing(s, e)}
                        title="Renombrar"
                        className="p-1 text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800 rounded"
                      >
                        <Edit2 className="w-3 h-3" />
                      </button>
                      {sessions.length > 1 && (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onDeleteSession(s.id);
                          }}
                          title="Eliminar"
                          className="p-1 text-zinc-400 hover:text-red-400 hover:bg-zinc-800 rounded"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      )}
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>

        {/* Footer info & Download ZIP */}
        <div className="p-3 border-t border-zinc-900 bg-zinc-950/80 flex flex-col gap-2">
          <a
            href="/api/download-project-zip"
            download="denji-android-project.zip"
            className="flex items-center justify-center gap-2 w-full py-2 px-3 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 hover:border-zinc-700 text-xs text-zinc-200 transition-colors group"
            title="Descargar ZIP con carpeta android/ y GitHub Actions listos"
          >
            <Download className="w-3.5 h-3.5 text-emerald-400 group-hover:scale-110 transition-transform" />
            <span className="font-medium">Descargar ZIP (GitHub / APK)</span>
          </a>

          <div className="text-[11px] text-zinc-400 flex items-center justify-between px-0.5">
            <div className="flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-amber-500" />
              <span>Motor: Gemini 3.8 Flash</span>
            </div>
            <span className="text-zinc-500">v1.2</span>
          </div>
        </div>
      </aside>
    </>
  );
};
