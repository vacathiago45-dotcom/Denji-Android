import React, { useState, useRef, useEffect } from 'react';
import {
  Send,
  Square,
  BookOpen,
  Code2,
  Sparkles,
  Bot,
  Copy,
  Check,
  RefreshCw,
  Volume2,
  VolumeX,
  Menu,
  Download,
  Trash2,
  AlertCircle,
  Flame,
} from 'lucide-react';
import { ChatMessage, ChatSession, MangaProjectNotes } from '../types';
import { MarkdownRenderer } from './MarkdownRenderer';

interface ChatAreaProps {
  session: ChatSession;
  onSendMessage: (content: string) => void;
  onRegenerate: () => void;
  onClearSession: () => void;
  onStopStreaming: () => void;
  isStreaming: boolean;
  onToggleSidebar: () => void;
  onOpenMangaModal: () => void;
  includeMangaContext: boolean;
  mangaNotes: MangaProjectNotes;
}

const STARTER_PROMPTS = [
  {
    category: 'Manga Ecos',
    icon: BookOpen,
    label: 'Guion y escena de Ecos',
    prompt: 'Denji, ayúdame a planear la escena clímax de este capítulo de Ecos. Quiero que el ritmo de las viñetas y el impacto visual peguen fuerte.',
  },
  {
    category: 'Manga Ecos',
    icon: Flame,
    label: 'Sistema de poder de Ecos',
    prompt: 'Tengo dudas con una habilidad en el sistema de poder de Ecos. Decime de frente si suena rota o poco creíble y cómo equilibrarla.',
  },
  {
    category: 'Programación',
    icon: Code2,
    label: 'Arquitectura & Código',
    prompt: 'Tengo que estructurar una funcionalidad de código y quiero tu opinión sincera sobre qué arquitectura usar sin sobrecomplicarme al pedo.',
  },
  {
    category: 'IA & Proyectos',
    icon: Bot,
    label: 'Flujos con Inteligencia Artificial',
    prompt: '¿Cómo ves meter un flujo con IA para agilizar mi proceso de trabajo sin perder calidad ni originalidad?',
  },
  {
    category: 'Cotidiano',
    icon: Sparkles,
    label: 'Charla tranquila',
    prompt: '¿Qué onda, Denji? ¿Cómo hacés para mantener el foco y la constancia cuando te da pereza arrancar?',
  },
];

export const ChatArea: React.FC<ChatAreaProps> = ({
  session,
  onSendMessage,
  onRegenerate,
  onClearSession,
  onStopStreaming,
  isStreaming,
  onToggleSidebar,
  onOpenMangaModal,
  includeMangaContext,
  mangaNotes,
}) => {
  const [input, setInput] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [speakingId, setSpeakingId] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [session.messages, isStreaming]);

  // Adjust textarea height automatically
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 180)}px`;
    }
  }, [input]);

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!input.trim() || isStreaming) return;
    const content = input.trim();
    setInput('');
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }
    onSendMessage(content);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  const handleCopyMessage = async (id: string, text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 2000);
    } catch {
      // ignore
    }
  };

  const handleSpeak = (id: string, text: string) => {
    if (!('speechSynthesis' in window)) return;

    if (speakingId === id) {
      window.speechSynthesis.cancel();
      setSpeakingId(null);
      return;
    }

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'es-ES';
    utterance.rate = 1.05;
    utterance.pitch = 0.95;

    utterance.onend = () => setSpeakingId(null);
    utterance.onerror = () => setSpeakingId(null);

    setSpeakingId(id);
    window.speechSynthesis.speak(utterance);
  };

  const handleExportChat = () => {
    if (session.messages.length === 0) return;
    const exportText = session.messages
      .map(
        (m) =>
          `[${new Date(m.timestamp).toLocaleTimeString()}] ${
            m.role === 'user' ? 'TÚ' : 'DENJI'
          }:\n${m.content}\n\n`
      )
      .join('---\n\n');

    const blob = new Blob([exportText], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${session.title || 'chat-denji'}.md`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-zinc-900 overflow-hidden relative">
      {/* Chat Top Bar */}
      <header className="h-16 px-4 md:px-6 border-b border-zinc-800/80 bg-zinc-950/70 backdrop-blur-md flex items-center justify-between z-10 shrink-0">
        <div className="flex items-center gap-3 min-w-0">
          <button
            onClick={onToggleSidebar}
            className="md:hidden p-2 rounded-lg text-zinc-400 hover:text-zinc-100 hover:bg-zinc-800"
            title="Abrir menú"
          >
            <Menu className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-3 min-w-0">
            <div className="relative shrink-0">
              <div className="w-9 h-9 rounded-xl bg-linear-to-br from-amber-500 to-amber-600 flex items-center justify-center text-zinc-950 font-black text-sm shadow-sm">
                D
              </div>
              <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-emerald-500 border-2 border-zinc-950" />
            </div>

            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <h1 className="text-sm font-bold text-zinc-100 truncate">
                  {session.title || 'Denji'}
                </h1>
                <span className="text-[11px] font-medium text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-full border border-amber-500/20 shrink-0">
                  Gemini 3.8 Flash
                </span>
              </div>
              <div className="text-xs text-zinc-400 flex items-center gap-2 truncate">
                {isStreaming ? (
                  <span className="text-amber-400 flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-ping" />
                    Denji está escribiendo...
                  </span>
                ) : (
                  <span>Tranqui, escuchando</span>
                )}
                {includeMangaContext && mangaNotes.title && (
                  <>
                    <span className="text-zinc-600">•</span>
                    <span className="text-amber-300/80 truncate">
                      Manga: {mangaNotes.title}
                    </span>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Header Actions */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={onOpenMangaModal}
            className={`hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition ${
              includeMangaContext
                ? 'bg-amber-500/10 border-amber-500/30 text-amber-300 hover:bg-amber-500/20'
                : 'bg-zinc-850 border-zinc-700/60 text-zinc-400 hover:text-zinc-200'
            }`}
            title="Contexto del Manga"
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>Contexto Manga</span>
            {includeMangaContext && (
              <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
            )}
          </button>

          <button
            onClick={handleExportChat}
            disabled={session.messages.length === 0}
            className="p-2 rounded-lg text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800 disabled:opacity-30 disabled:pointer-events-none transition"
            title="Descargar conversación (.md)"
          >
            <Download className="w-4 h-4" />
          </button>

          <button
            onClick={onClearSession}
            disabled={session.messages.length === 0}
            className="p-2 rounded-lg text-zinc-400 hover:text-red-400 hover:bg-zinc-800 disabled:opacity-30 disabled:pointer-events-none transition"
            title="Limpiar chat actual"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto px-4 md:px-8 py-6 space-y-6">
        {session.messages.length === 0 ? (
          /* Welcome View */
          <div className="max-w-2xl mx-auto py-8 space-y-6">
            <div className="p-6 rounded-2xl bg-zinc-950/80 border border-zinc-800 text-center relative overflow-hidden">
              <div className="absolute top-0 right-0 w-48 h-48 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />
              <div className="w-14 h-14 mx-auto mb-4 rounded-2xl bg-linear-to-tr from-amber-500 to-amber-600 flex items-center justify-center text-zinc-950 font-black text-2xl shadow-lg shadow-amber-500/20">
                D
              </div>
              <h2 className="text-xl font-bold text-zinc-100 mb-2">
                ¿Qué onda, che? Acá estoy.
              </h2>
              <p className="text-zinc-400 text-sm max-w-lg mx-auto leading-relaxed">
                Soy <span className="text-amber-400 font-semibold">Denji</span>, tu asistente personal y compa de proyectos.
                Podemos meterle al guion de <strong className="text-zinc-200">Ecos</strong>, destrabar bugs de código, ver temas de IA
                o simplemente charlar de la vida sin vueltas, directo y sincero.
              </p>

              {includeMangaContext && mangaNotes.title && (
                <div className="mt-4 inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-xs text-amber-300">
                  <BookOpen className="w-3.5 h-3.5" />
                  <span>Proyecto activo cargado: <strong>{mangaNotes.title}</strong></span>
                </div>
              )}
            </div>

            {/* Quick Starter Cards */}
            <div className="space-y-2">
              <span className="text-xs font-semibold text-zinc-400 uppercase tracking-wider block px-1">
                Disparadores rápidos para empezar:
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {STARTER_PROMPTS.map((item, idx) => {
                  const Icon = item.icon;
                  return (
                    <button
                      key={idx}
                      onClick={() => onSendMessage(item.prompt)}
                      className="p-3.5 rounded-xl bg-zinc-950/60 hover:bg-zinc-850/80 border border-zinc-800/80 hover:border-amber-500/40 text-left transition group"
                    >
                      <div className="flex items-center gap-2 mb-1">
                        <Icon className="w-3.5 h-3.5 text-amber-400 group-hover:scale-110 transition-transform" />
                        <span className="text-xs font-semibold text-zinc-200 group-hover:text-amber-300">
                          {item.label}
                        </span>
                      </div>
                      <p className="text-xs text-zinc-400 line-clamp-2 leading-relaxed">
                        {item.prompt}
                      </p>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        ) : (
          /* Conversation Message List */
          <div className="max-w-3xl mx-auto space-y-6">
            {session.messages.map((message, index) => {
              const isUser = message.role === 'user';
              const isLastAssistantMessage =
                !isUser && index === session.messages.length - 1;

              return (
                <div
                  key={message.id}
                  className={`flex gap-3.5 ${isUser ? 'justify-end' : 'justify-start'}`}
                >
                  {/* Assistant Avatar */}
                  {!isUser && (
                    <div className="shrink-0 w-8 h-8 rounded-xl bg-linear-to-br from-amber-500 to-amber-600 flex items-center justify-center text-zinc-950 font-black text-xs shadow-md shadow-amber-500/20 mt-1">
                      D
                    </div>
                  )}

                  {/* Message Bubble */}
                  <div
                    className={`relative group max-w-[88%] md:max-w-[80%] rounded-2xl p-4 transition ${
                      isUser
                        ? 'bg-amber-500 text-zinc-950 rounded-tr-xs font-medium shadow-md shadow-amber-500/10'
                        : message.error
                        ? 'bg-red-950/40 border border-red-800/70 text-red-200 rounded-tl-xs'
                        : 'bg-zinc-950 border border-zinc-800/90 rounded-tl-xs shadow-sm'
                    }`}
                  >
                    {/* Header info */}
                    <div className="flex items-center justify-between gap-3 mb-1 text-[11px] opacity-75">
                      <span className={isUser ? 'text-zinc-900 font-semibold' : 'text-zinc-400 font-medium'}>
                        {isUser ? 'Vos' : 'Denji'}
                      </span>
                      <span className={isUser ? 'text-zinc-900/70' : 'text-zinc-400'}>
                        {new Date(message.timestamp).toLocaleTimeString([], {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </span>
                    </div>

                    {/* Content */}
                    {isUser ? (
                      <p className="whitespace-pre-wrap text-sm leading-relaxed">
                        {message.content}
                      </p>
                    ) : message.error ? (
                      <div className="space-y-2">
                        <div className="flex items-center gap-2 text-sm text-red-300 font-semibold">
                          <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
                          <span>Hubo un problema al generar la respuesta</span>
                        </div>
                        <p className="text-xs text-red-300/80 leading-relaxed font-mono">
                          {message.content}
                        </p>
                        <button
                          onClick={onRegenerate}
                          className="mt-2 inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-red-900/50 hover:bg-red-800/60 text-xs font-medium text-red-200 border border-red-700/50 transition"
                        >
                          <RefreshCw className="w-3 h-3" />
                          Reintentar
                        </button>
                      </div>
                    ) : (
                      <MarkdownRenderer
                        content={message.content}
                        isStreaming={message.isStreaming}
                      />
                    )}

                    {/* Assistant Message Actions Toolbar */}
                    {!isUser && !message.error && !message.isStreaming && (
                      <div className="mt-3 pt-2 border-t border-zinc-800/80 flex items-center justify-between text-zinc-400 text-xs">
                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => handleCopyMessage(message.id, message.content)}
                            className="p-1.5 hover:text-zinc-200 hover:bg-zinc-800/80 rounded transition flex items-center gap-1 text-[11px]"
                            title="Copiar texto"
                          >
                            {copiedId === message.id ? (
                              <>
                                <Check className="w-3 h-3 text-emerald-400" />
                                <span className="text-emerald-400">Copiado</span>
                              </>
                            ) : (
                              <>
                                <Copy className="w-3 h-3" />
                                <span>Copiar</span>
                              </>
                            )}
                          </button>

                          <button
                            onClick={() => handleSpeak(message.id, message.content)}
                            className="p-1.5 hover:text-zinc-200 hover:bg-zinc-800/80 rounded transition flex items-center gap-1 text-[11px]"
                            title={speakingId === message.id ? 'Detener lectura' : 'Escuchar respuesta'}
                          >
                            {speakingId === message.id ? (
                              <>
                                <VolumeX className="w-3 h-3 text-amber-400 animate-pulse" />
                                <span className="text-amber-400">Detener</span>
                              </>
                            ) : (
                              <>
                                <Volume2 className="w-3 h-3" />
                                <span>Escuchar</span>
                              </>
                            )}
                          </button>
                        </div>

                        {isLastAssistantMessage && !isStreaming && (
                          <button
                            onClick={onRegenerate}
                            className="p-1.5 hover:text-amber-300 hover:bg-zinc-800/80 rounded transition flex items-center gap-1 text-[11px]"
                            title="Regenerar respuesta con Denji"
                          >
                            <RefreshCw className="w-3 h-3" />
                            <span>Regenerar</span>
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
            <div ref={messagesEndRef} />
          </div>
        )}
      </div>

      {/* Bottom Input Area */}
      <footer className="p-4 md:px-8 border-t border-zinc-800/80 bg-zinc-950/80 backdrop-blur-md shrink-0">
        <div className="max-w-3xl mx-auto space-y-2">
          {/* Quick context pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto text-[11px] pb-1 scrollbar-none">
            <span className="text-zinc-400 shrink-0 font-medium">Sugerir:</span>
            {[
              'Revisemos esta escena de Ecos',
              'Fijate este bug de código',
              'Dame tu opinión sincera',
              '¿Cómo ves esta idea?',
            ].map((tag, i) => (
              <button
                key={i}
                type="button"
                onClick={() => setInput(tag)}
                className="px-2.5 py-1 rounded-lg bg-zinc-900 hover:bg-zinc-800 text-zinc-300 hover:text-amber-300 border border-zinc-800 shrink-0 transition"
              >
                {tag}
              </button>
            ))}
          </div>

          {/* Form */}
          <form
            onSubmit={handleSubmit}
            className="relative flex items-end gap-2 p-2 rounded-2xl bg-zinc-900 border border-zinc-750 focus-within:border-amber-500/80 shadow-lg transition-colors"
          >
            <textarea
              ref={textareaRef}
              rows={1}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Hablá con Denji... (Enter para enviar, Shift+Enter para salto de línea)"
              className="flex-1 max-h-44 p-2 bg-transparent text-zinc-100 placeholder-zinc-500 text-sm focus:outline-hidden resize-none leading-relaxed"
            />

            {isStreaming ? (
              <button
                type="button"
                onClick={onStopStreaming}
                className="p-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-amber-400 font-semibold transition flex items-center justify-center shrink-0"
                title="Detener respuesta"
              >
                <Square className="w-4 h-4 fill-amber-400" />
              </button>
            ) : (
              <button
                type="submit"
                disabled={!input.trim()}
                className="p-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 disabled:bg-zinc-800 disabled:text-zinc-600 text-zinc-950 font-bold transition flex items-center justify-center shrink-0 active:scale-95 shadow-sm shadow-amber-500/20"
                title="Enviar mensaje"
              >
                <Send className="w-4 h-4 stroke-[2.5]" />
              </button>
            )}
          </form>

          <div className="flex items-center justify-between text-[11px] text-zinc-400 px-1">
            <span>Denji • Tu asistente personal y compa de proyectos</span>
            <span>{input.length > 0 && `${input.length} caracteres`}</span>
          </div>
        </div>
      </footer>
    </div>
  );
};
