import React, { useState } from 'react';
import { BookOpen, Sparkles, X, Check, Save, Flame, HelpCircle } from 'lucide-react';
import { MangaProjectNotes } from '../types';

interface MangaProjectModalProps {
  isOpen: boolean;
  onClose: () => void;
  notes: MangaProjectNotes;
  onSave: (updated: MangaProjectNotes) => void;
  includeContext: boolean;
  onToggleIncludeContext: (include: boolean) => void;
  onAskDenjiAboutManga: (prompt: string) => void;
}

export const MangaProjectModal: React.FC<MangaProjectModalProps> = ({
  isOpen,
  onClose,
  notes,
  onSave,
  includeContext,
  onToggleIncludeContext,
  onAskDenjiAboutManga,
}) => {
  const [formData, setFormData] = useState<MangaProjectNotes>(notes);
  const [isSavedNotice, setIsSavedNotice] = useState(false);

  if (!isOpen) return null;

  const handleChange = (field: keyof MangaProjectNotes, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleSave = () => {
    onSave(formData);
    setIsSavedNotice(true);
    setTimeout(() => setIsSavedNotice(false), 2000);
  };

  const applyPresetTemplate = () => {
    setFormData({
      title: 'Ecos',
      genre: 'Fantasía Oscura / Misterio Sobrenatural / Shonen Seinen',
      synopsis:
        'En un mundo donde los ecos y recuerdos de acontecimientos trágicos cobran resonancia y alteran la realidad, los protagonistas deben lidiar con las repercusiones de su pasado mientras enfrentan entidades que se alimentan del olvido.',
      protagonist:
        'Protagonista determinado pero impulsivo, que carga con las consecuencias de un pacto previo y busca comprender el origen de los ecos.',
      powerSystem:
        'Sintonización de Ecos: canalización de frecuencias de memoria y resonancia espiritual. Regla crucial: cada manifestación exige un costo equivalente y deja secuelas perceptibles en el entorno.',
      currentGoal: 'Definir el conflicto central del capítulo inicial, el primer encuentro clave y pulir las limitaciones del sistema de poder.',
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs">
      <div className="relative w-full max-w-2xl bg-zinc-900 border border-zinc-700/80 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-zinc-800 bg-zinc-950/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-zinc-100 flex items-center gap-2">
                Ficha del Proyecto de Manga
                <span className="text-xs px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20">
                  Denji Context
                </span>
              </h2>
              <p className="text-xs text-zinc-400">
                Denji utilizará esta información para darte consejos alineados a tu historia
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-zinc-100 hover:bg-zinc-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4 text-sm">
          {/* Active Context Toggle */}
          <div className="flex items-center justify-between p-3.5 rounded-xl bg-zinc-800/60 border border-zinc-700/60">
            <div className="space-y-0.5">
              <div className="font-medium text-zinc-200 flex items-center gap-2">
                <span>Vincular contexto a las respuestas de Denji</span>
                {includeContext && (
                  <span className="text-[10px] px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-400 font-semibold border border-emerald-500/30">
                    Activo
                  </span>
                )}
              </div>
              <p className="text-xs text-zinc-400">
                Cuando está activado, Denji recordará el título, poderes y personajes en cada mensaje.
              </p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={includeContext}
                onChange={(e) => onToggleIncludeContext(e.target.checked)}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-zinc-700 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-zinc-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-amber-500"></div>
            </label>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-zinc-300 uppercase tracking-wider mb-1.5">
                Título del Manga / Proyecto
              </label>
              <input
                type="text"
                placeholder="Ej. Cazadores de Sombras"
                value={formData.title}
                onChange={(e) => handleChange('title', e.target.value)}
                className="w-full px-3.5 py-2 rounded-lg bg-zinc-950 border border-zinc-700 text-zinc-100 placeholder-zinc-500 focus:outline-hidden focus:border-amber-400 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-zinc-300 uppercase tracking-wider mb-1.5">
                Género & Tono
              </label>
              <input
                type="text"
                placeholder="Ej. Shonen de acción, misterio, psicológico"
                value={formData.genre}
                onChange={(e) => handleChange('genre', e.target.value)}
                className="w-full px-3.5 py-2 rounded-lg bg-zinc-950 border border-zinc-700 text-zinc-100 placeholder-zinc-500 focus:outline-hidden focus:border-amber-400 text-sm"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-zinc-300 uppercase tracking-wider mb-1.5">
              Premisa / Sinopsis Central
            </label>
            <textarea
              rows={2}
              placeholder="¿De qué trata tu historia en pocas líneas? ¿Cuál es el conflicto principal?"
              value={formData.synopsis}
              onChange={(e) => handleChange('synopsis', e.target.value)}
              className="w-full px-3.5 py-2 rounded-lg bg-zinc-950 border border-zinc-700 text-zinc-100 placeholder-zinc-500 focus:outline-hidden focus:border-amber-400 text-sm resize-none"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-zinc-300 uppercase tracking-wider mb-1.5">
                Protagonista y Motivación
              </label>
              <textarea
                rows={2}
                placeholder="Nombre, personalidad clave, qué busca y qué debilidad o conflicto tiene"
                value={formData.protagonist}
                onChange={(e) => handleChange('protagonist', e.target.value)}
                className="w-full px-3.5 py-2 rounded-lg bg-zinc-950 border border-zinc-700 text-zinc-100 placeholder-zinc-500 focus:outline-hidden focus:border-amber-400 text-sm resize-none"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-zinc-300 uppercase tracking-wider mb-1.5">
                Sistema de Poderes / Reglas de Magia
              </label>
              <textarea
                rows={2}
                placeholder="¿Cómo funciona el poder? ¿Cuáles son sus limitaciones y costo?"
                value={formData.powerSystem}
                onChange={(e) => handleChange('powerSystem', e.target.value)}
                className="w-full px-3.5 py-2 rounded-lg bg-zinc-950 border border-zinc-700 text-zinc-100 placeholder-zinc-500 focus:outline-hidden focus:border-amber-400 text-sm resize-none"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-zinc-300 uppercase tracking-wider mb-1.5">
              Objetivo Actual / Escena en la que trabajas
            </label>
            <input
              type="text"
              placeholder="Ej. Planear el giro del capítulo 3, diseñar el rival o pulir el prólogo"
              value={formData.currentGoal}
              onChange={(e) => handleChange('currentGoal', e.target.value)}
              className="w-full px-3.5 py-2 rounded-lg bg-zinc-950 border border-zinc-700 text-zinc-100 placeholder-zinc-500 focus:outline-hidden focus:border-amber-400 text-sm"
            />
          </div>

          {/* Quick Denji Prompts for Manga */}
          <div className="pt-2 border-t border-zinc-800">
            <span className="block text-xs font-semibold text-amber-400/90 mb-2 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5" />
              Preguntarle directo a Denji sobre este proyecto:
            </span>
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => {
                  onSave(formData);
                  onAskDenjiAboutManga('Denji, revisá la premisa y sistema de poderes de Ecos y decime con total sinceridad si funciona o qué parte te parece floja.');
                  onClose();
                }}
                className="px-2.5 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-750 text-xs text-zinc-200 hover:text-amber-300 border border-zinc-700 transition flex items-center gap-1.5"
              >
                <Flame className="w-3.5 h-3.5 text-amber-500" />
                "Opinión sincera de Ecos"
              </button>
              <button
                type="button"
                onClick={() => {
                  onSave(formData);
                  onAskDenjiAboutManga('Denji, ayúdame a estructurar la distribución de viñetas y el ritmo visual para la escena de Ecos en la que estoy laburando.');
                  onClose();
                }}
                className="px-2.5 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-750 text-xs text-zinc-200 hover:text-amber-300 border border-zinc-700 transition flex items-center gap-1.5"
              >
                <BookOpen className="w-3.5 h-3.5 text-amber-500" />
                "Viñetas y ritmo de Ecos"
              </button>
              <button
                type="button"
                onClick={applyPresetTemplate}
                className="px-2.5 py-1.5 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-xs text-amber-300 border border-amber-500/30 transition flex items-center gap-1.5 ml-auto"
                title="Cargar ejemplo de inspiración"
              >
                <HelpCircle className="w-3.5 h-3.5" />
                Cargar plantilla de ejemplo
              </button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-6 py-4 border-t border-zinc-800 bg-zinc-950/60">
          <span className="text-xs text-zinc-400">
            {isSavedNotice ? (
              <span className="text-emerald-400 flex items-center gap-1 font-medium">
                <Check className="w-3.5 h-3.5" /> Cambios guardados correctamente
              </span>
            ) : (
              'Los datos se guardan en tu navegador automáticamente'
            )}
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-lg text-sm text-zinc-300 hover:text-zinc-100 hover:bg-zinc-800 transition"
            >
              Cerrar
            </button>
            <button
              onClick={handleSave}
              className="px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-zinc-950 font-semibold text-sm transition flex items-center gap-1.5 shadow-md shadow-amber-500/20"
            >
              <Save className="w-4 h-4" />
              Guardar Ficha
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
