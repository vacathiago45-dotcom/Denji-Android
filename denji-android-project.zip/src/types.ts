export type MessageRole = 'user' | 'model';

export interface ChatMessage {
  id: string;
  role: MessageRole;
  content: string;
  timestamp: number;
  isStreaming?: boolean;
  error?: boolean;
}

export interface MangaProjectNotes {
  title: string;
  genre: string;
  synopsis: string;
  protagonist: string;
  powerSystem: string;
  currentGoal: string;
}

export interface ChatSession {
  id: string;
  title: string;
  messages: ChatMessage[];
  createdAt: number;
  updatedAt: number;
  category?: 'manga' | 'coding' | 'ai' | 'general';
}
