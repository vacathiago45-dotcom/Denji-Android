/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useRef } from 'react';
import { Sidebar } from './components/Sidebar';
import { ChatArea } from './components/ChatArea';
import { MangaProjectModal } from './components/MangaProjectModal';
import { ChatSession, ChatMessage, MangaProjectNotes } from './types';
import { getApiBaseUrl } from './config';

const STORAGE_KEYS = {
  SESSIONS: 'denji_chat_sessions_v1',
  ACTIVE_SESSION: 'denji_active_session_v1',
  MANGA_NOTES: 'denji_manga_notes_v1',
  INCLUDE_MANGA_CONTEXT: 'denji_include_manga_context_v1',
};

const DEFAULT_MANGA_NOTES: MangaProjectNotes = {
  title: 'Ecos',
  genre: 'Fantasía Oscura / Misterio Sobrenatural / Shonen Seinen',
  synopsis:
    'En un mundo donde los ecos y recuerdos de acontecimientos trágicos cobran resonancia y alteran la realidad, los protagonistas deben lidiar con las repercusiones de su pasado mientras enfrentan entidades que se alimentan del olvido.',
  protagonist:
    'Protagonista decidido pero impulsivo, que carga con las consecuencias de un pacto previo y busca comprender el origen de los ecos.',
  powerSystem:
    'Sintonización de Ecos: canalización de frecuencias de memoria y resonancia espiritual con costos severos y secuelas en el entorno.',
  currentGoal:
    'Definir el conflicto central del capítulo inicial, el primer encuentro clave y pulir las limitaciones del sistema de poder.',
};

function createInitialSession(): ChatSession {
  return {
    id: `session_${Date.now()}`,
    title: 'Nueva conversación',
    messages: [],
    createdAt: Date.now(),
    updatedAt: Date.now(),
    category: 'general',
  };
}

export default function App() {
  const [sessions, setSessions] = useState<ChatSession[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.SESSIONS);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.error('Failed to load sessions from storage:', e);
    }
    return [createInitialSession()];
  });

  const [activeSessionId, setActiveSessionId] = useState<string>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.ACTIVE_SESSION);
      if (saved) return saved;
    } catch {
      // ignore
    }
    return sessions[0]?.id || `session_${Date.now()}`;
  });

  const [mangaNotes, setMangaNotes] = useState<MangaProjectNotes>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.MANGA_NOTES);
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return DEFAULT_MANGA_NOTES;
  });

  const [includeMangaContext, setIncludeMangaContext] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.INCLUDE_MANGA_CONTEXT);
      if (saved !== null) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return true;
  });

  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isMangaModalOpen, setIsMangaModalOpen] = useState(false);
  const [isStreaming, setIsStreaming] = useState(false);

  const abortControllerRef = useRef<AbortController | null>(null);

  // Sync sessions to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.SESSIONS, JSON.stringify(sessions));
    } catch (e) {
      console.error('Error saving sessions:', e);
    }
  }, [sessions]);

  // Sync activeSessionId to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.ACTIVE_SESSION, activeSessionId);
    } catch (e) {
      console.error('Error saving active session ID:', e);
    }
  }, [activeSessionId]);

  // Sync mangaNotes to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.MANGA_NOTES, JSON.stringify(mangaNotes));
    } catch (e) {
      console.error('Error saving manga notes:', e);
    }
  }, [mangaNotes]);

  // Sync includeMangaContext to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(
        STORAGE_KEYS.INCLUDE_MANGA_CONTEXT,
        JSON.stringify(includeMangaContext)
      );
    } catch (e) {
      console.error('Error saving context toggle:', e);
    }
  }, [includeMangaContext]);

  const activeSession =
    sessions.find((s) => s.id === activeSessionId) || sessions[0];

  const formatMangaContextString = (notes: MangaProjectNotes): string => {
    const parts: string[] = [];
    if (notes.title) parts.push(`Manga: ${notes.title}`);
    if (notes.genre) parts.push(`Género: ${notes.genre}`);
    if (notes.synopsis) parts.push(`Premisa: ${notes.synopsis}`);
    if (notes.protagonist) parts.push(`Protagonista: ${notes.protagonist}`);
    if (notes.powerSystem) parts.push(`Sistema: ${notes.powerSystem}`);
    if (notes.currentGoal) parts.push(`Objetivo: ${notes.currentGoal}`);
    return parts.join(' | ');
  };

  const inferCategory = (text: string): 'manga' | 'coding' | 'ai' | 'general' => {
    const lower = text.toLowerCase();
    if (
      lower.includes('ecos') ||
      lower.includes('manga') ||
      lower.includes('guion') ||
      lower.includes('viñeta') ||
      lower.includes('capítulo') ||
      lower.includes('personaje') ||
      lower.includes('historia') ||
      lower.includes('shonen')
    ) {
      return 'manga';
    }
    if (
      lower.includes('código') ||
      lower.includes('codigo') ||
      lower.includes('bug') ||
      lower.includes('función') ||
      lower.includes('typescript') ||
      lower.includes('react') ||
      lower.includes('javascript') ||
      lower.includes('python') ||
      lower.includes('backend') ||
      lower.includes('frontend')
    ) {
      return 'coding';
    }
    if (
      lower.includes('ia') ||
      lower.includes('gemini') ||
      lower.includes('prompt') ||
      lower.includes('llm') ||
      lower.includes('modelo')
    ) {
      return 'ai';
    }
    return 'general';
  };

  const handleSendMessage = async (userText: string) => {
    if (!userText.trim() || isStreaming) return;

    const userMessage: ChatMessage = {
      id: `msg_${Date.now()}_u`,
      role: 'user',
      content: userText.trim(),
      timestamp: Date.now(),
    };

    const tempAssistantId = `msg_${Date.now()}_a`;
    const initialAssistantMessage: ChatMessage = {
      id: tempAssistantId,
      role: 'model',
      content: '',
      timestamp: Date.now(),
      isStreaming: true,
    };

    const isFirstMessage = activeSession.messages.length === 0;
    const newTitle = isFirstMessage
      ? userText.slice(0, 32) + (userText.length > 32 ? '...' : '')
      : activeSession.title;
    const newCategory = isFirstMessage ? inferCategory(userText) : activeSession.category;

    const updatedMessages = [...activeSession.messages, userMessage, initialAssistantMessage];

    setSessions((prev) =>
      prev.map((s) =>
        s.id === activeSession.id
          ? {
              ...s,
              title: newTitle,
              category: newCategory,
              updatedAt: Date.now(),
              messages: updatedMessages,
            }
          : s
      )
    );

    setIsStreaming(true);
    const abortController = new AbortController();
    abortControllerRef.current = abortController;

    // Filter recent messages for Gemini API to minimize payload and token processing latency
    const recentMessages = activeSession.messages.slice(-14);
    const historyForApi = [...recentMessages, userMessage].map((m) => ({
      role: m.role,
      content: m.content,
    }));

    const mangaContextText =
      includeMangaContext && (mangaNotes.title || mangaNotes.synopsis || mangaNotes.powerSystem)
        ? formatMangaContextString(mangaNotes)
        : undefined;

    let accumulatedContent = '';

    try {
      const response = await fetch(`${getApiBaseUrl()}/api/chat/stream`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: historyForApi,
          mangaContext: mangaContextText,
        }),
        signal: abortController.signal,
      });

      if (!response.ok) {
        let errMessage = `Error del servidor (${response.status})`;
        try {
          const errData = await response.json();
          if (errData.error) errMessage = errData.error;
        } catch {
          // ignore
        }
        throw new Error(errMessage);
      }

      const reader = response.body?.getReader();
      const decoder = new TextDecoder();

      if (reader) {
        let done = false;
        let buffer = '';

        while (!done) {
          const { value, done: readerDone } = await reader.read();
          done = readerDone;

          if (value) {
            buffer += decoder.decode(value, { stream: true });
            const blocks = buffer.split('\n\n');
            buffer = blocks.pop() || '';

            for (const block of blocks) {
              const lines = block.split('\n');
              for (const line of lines) {
                if (line.startsWith('data: ')) {
                  const dataStr = line.replace('data: ', '').trim();
                  if (dataStr === '[DONE]') {
                    done = true;
                    break;
                  }

                  try {
                    const parsed = JSON.parse(dataStr);
                    if (parsed.error) {
                      throw new Error(parsed.error);
                    }
                    if (parsed.text) {
                      accumulatedContent += parsed.text;

                      setSessions((prev) =>
                        prev.map((s) => {
                          if (s.id !== activeSession.id) return s;
                          return {
                            ...s,
                            messages: s.messages.map((m) =>
                              m.id === tempAssistantId
                                ? { ...m, content: accumulatedContent, isStreaming: true }
                                : m
                            ),
                          };
                        })
                      );
                    }
                  } catch (e: unknown) {
                    if (e instanceof Error && e.message.includes('Error')) {
                      throw e;
                    }
                  }
                }
              }
            }
          }
        }
      }

      // Mark streaming finished
      setSessions((prev) =>
        prev.map((s) => {
          if (s.id !== activeSession.id) return s;
          return {
            ...s,
            updatedAt: Date.now(),
            messages: s.messages.map((m) =>
              m.id === tempAssistantId
                ? {
                    ...m,
                    content: accumulatedContent || 'No hubo respuesta recibida.',
                    isStreaming: false,
                  }
                : m
            ),
          };
        })
      );
    } catch (err: unknown) {
      if (err instanceof Error && err.name === 'AbortError') {
        // Stream aborted by user
        setSessions((prev) =>
          prev.map((s) => {
            if (s.id !== activeSession.id) return s;
            return {
              ...s,
              messages: s.messages.map((m) =>
                m.id === tempAssistantId
                  ? {
                      ...m,
                      content: accumulatedContent || '(Generación detenida por el usuario)',
                      isStreaming: false,
                    }
                  : m
              ),
            };
          })
        );
      } else {
        const errorMsg =
          err instanceof Error
            ? err.message
            : 'Ocurrió un error al contactar con Denji.';

        setSessions((prev) =>
          prev.map((s) => {
            if (s.id !== activeSession.id) return s;
            return {
              ...s,
              messages: s.messages.map((m) =>
                m.id === tempAssistantId
                  ? {
                      ...m,
                      content: errorMsg,
                      isStreaming: false,
                      error: true,
                    }
                  : m
              ),
            };
          })
        );
      }
    } finally {
      setIsStreaming(false);
      abortControllerRef.current = null;
    }
  };

  const handleRegenerate = () => {
    if (activeSession.messages.length < 2 || isStreaming) return;

    // Find the last user message
    let lastUserIndex = -1;
    for (let i = activeSession.messages.length - 1; i >= 0; i--) {
      if (activeSession.messages[i].role === 'user') {
        lastUserIndex = i;
        break;
      }
    }

    if (lastUserIndex === -1) return;

    const userMessage = activeSession.messages[lastUserIndex];
    // Keep history up to that user message, removing subsequent assistant messages
    const trimmedMessages = activeSession.messages.slice(0, lastUserIndex);

    setSessions((prev) =>
      prev.map((s) =>
        s.id === activeSession.id ? { ...s, messages: trimmedMessages } : s
      )
    );

    handleSendMessage(userMessage.content);
  };

  const handleStopStreaming = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
  };

  const handleNewSession = () => {
    if (isStreaming) handleStopStreaming();
    const newSession = createInitialSession();
    setSessions((prev) => [newSession, ...prev]);
    setActiveSessionId(newSession.id);
    setIsSidebarOpen(false);
  };

  const handleDeleteSession = (id: string) => {
    if (isStreaming && id === activeSessionId) {
      handleStopStreaming();
    }
    const remaining = sessions.filter((s) => s.id !== id);
    if (remaining.length === 0) {
      const fresh = createInitialSession();
      setSessions([fresh]);
      setActiveSessionId(fresh.id);
    } else {
      setSessions(remaining);
      if (activeSessionId === id) {
        setActiveSessionId(remaining[0].id);
      }
    }
  };

  const handleRenameSession = (id: string, newTitle: string) => {
    setSessions((prev) =>
      prev.map((s) => (s.id === id ? { ...s, title: newTitle } : s))
    );
  };

  const handleClearSession = () => {
    if (isStreaming) handleStopStreaming();
    setSessions((prev) =>
      prev.map((s) => (s.id === activeSession.id ? { ...s, messages: [] } : s))
    );
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-zinc-950 font-sans text-zinc-100 antialiased selection:bg-amber-500 selection:text-zinc-950">
      <Sidebar
        sessions={sessions}
        activeSessionId={activeSession.id}
        onSelectSession={(id) => {
          if (isStreaming) handleStopStreaming();
          setActiveSessionId(id);
          setIsSidebarOpen(false);
        }}
        onNewSession={handleNewSession}
        onDeleteSession={handleDeleteSession}
        onRenameSession={handleRenameSession}
        isOpen={isSidebarOpen}
        onToggleOpen={() => setIsSidebarOpen((prev) => !prev)}
        onOpenMangaModal={() => setIsMangaModalOpen(true)}
        hasMangaContext={Boolean(
          includeMangaContext &&
            (mangaNotes.title || mangaNotes.synopsis || mangaNotes.powerSystem)
        )}
      />

      <ChatArea
        session={activeSession}
        onSendMessage={handleSendMessage}
        onRegenerate={handleRegenerate}
        onClearSession={handleClearSession}
        onStopStreaming={handleStopStreaming}
        isStreaming={isStreaming}
        onToggleSidebar={() => setIsSidebarOpen((prev) => !prev)}
        onOpenMangaModal={() => setIsMangaModalOpen(true)}
        includeMangaContext={includeMangaContext}
        mangaNotes={mangaNotes}
      />

      <MangaProjectModal
        isOpen={isMangaModalOpen}
        onClose={() => setIsMangaModalOpen(false)}
        notes={mangaNotes}
        onSave={(updated) => setMangaNotes(updated)}
        includeContext={includeMangaContext}
        onToggleIncludeContext={(include) => setIncludeMangaContext(include)}
        onAskDenjiAboutManga={(prompt) => {
          setIsMangaModalOpen(false);
          handleSendMessage(prompt);
        }}
      />
    </div>
  );
}
