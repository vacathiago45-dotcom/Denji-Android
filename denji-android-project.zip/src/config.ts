import { Capacitor } from '@capacitor/core';

/**
 * Returns the base API URL.
 * When running inside a native Android Capacitor app, requests must point
 * to the remote hosted backend rather than the local device origin.
 */
export const getApiBaseUrl = (): string => {
  // 1. Check for custom user-configured backend endpoint in localStorage
  try {
    const customUrl = localStorage.getItem('denji_custom_backend_url');
    if (customUrl && customUrl.trim()) {
      return customUrl.trim().replace(/\/+$/, '');
    }
  } catch {
    // Ignore storage restrictions
  }

  // 2. Check for build-time environment variable
  if (import.meta.env.VITE_API_BASE_URL) {
    return import.meta.env.VITE_API_BASE_URL.replace(/\/+$/, '');
  }

  // 3. When running inside the native Android or iOS app shell:
  if (Capacitor.isNativePlatform()) {
    return 'https://ais-dev-byhqf5niqhpvseh2br7tbs-839969723838.us-east1.run.app';
  }

  // 4. Default to relative path for web browser
  return '';
};
