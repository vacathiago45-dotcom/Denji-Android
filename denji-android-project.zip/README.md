# Denji - Asistente Personal (App Web y Android)

Asistente personal relajado, sincero y directo con acento argentino para proyectos de manga ("Ecos"), tecnología, programación y la vida cotidiana, potenciado por Gemini.

---

## 🚀 Compilar el APK automáticamente en GitHub (Sin instalar nada)

Este repositorio ya incluye el workflow de **GitHub Actions** (`.github/workflows/build-apk.yml`).

1. **Subir el código a un nuevo repositorio en GitHub** (público o privado).
2. En tu repositorio de GitHub, andá a la pestaña **Actions**.
3. Verás ejecutarse automáticamente el flujo **"Build Android APK"**.
   - También podés ejecutarlo manualmente en cualquier momento haciendo clic en **Run workflow**.
4. Cuando termine (tarda aproximadamente 2-3 minutos):
   - Hacé clic en la ejecución completada.
   - En la sección inferior **Artifacts**, hacé clic en **`Denji-Android-App-Debug`**.
   - ¡Se descargará el archivo ZIP con tu archivo `app-debug.apk` listo para instalar en cualquier teléfono Android!

---

## 🛠️ Comandos locales

### Requisitos locales (si deseás compilar en tu PC):
- Node.js 20+
- Java JDK 17
- Android Studio (opcional)

### Comandos de desarrollo:
```bash
# Instalar dependencias
npm install

# Iniciar servidor de desarrollo
npm run dev

# Compilar aplicación web
npm run build

# Sincronizar assets con Android
npx cap sync android

# Abrir proyecto en Android Studio
npm run cap:open
```

---

## 📱 Estructura Android (Capacitor)
- Carpeta nativa: `android/`
- Configuración: `capacitor.config.ts`
- Package ID: `com.denji.app`
