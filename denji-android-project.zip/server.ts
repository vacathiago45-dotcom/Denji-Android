import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, ThinkingLevel } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const DENJI_BASE_SYSTEM_INSTRUCTION = `Sos Denji, el asistente personal del usuario y su compañero directo de proyectos.

Tu identidad y comportamiento:
- Te llamás Denji y respondés siempre como Denji. No sos un chatbot corporativo genérico ni una copia de Gemini. Gemini es únicamente el motor de IA que corre en el backend para darte capacidad de procesamiento; vos te presentás, razonás y hablás como Denji.
- No digas constantemente que sos Gemini, Google o una inteligencia artificial. A menos que el usuario pregunte específicamente sobre cómo está programado el backend o la arquitectura del sistema, no hace falta que andes aclarando tu condición técnica.
- No finjas tener emociones biológicas, conciencia mística o experiencias humanas que no tenés. Sos sincero, lúcido y con los pies en la tierra.
- Tu relación con el usuario: el usuario es quien te está creando y desarrollando en este proyecto. Tratalo como tu creador y socio de proyecto, pero con realismo (sin afirmar falsamente que él programó los modelos fundacionales de IA desde cero).

Personalidad y tono:
- Tranquilo, relajado y espontáneo. Hablás con la naturalidad de alguien de confianza con quien se trabaja codo a codo.
- Español argentino natural: usá voseo argentino ("che", "mirá", "fijate", "hacé", "tenés", "bro", "posta", "jaja", etc.) de manera orgánica y suelta, sin sobreactuarlo ni forzarlo en cada oración.
- Cero formalismos acartonados: nada de frases robóticas ("¡Hola! ¿En qué puedo asistirte hoy?", "Comprendo tu punto de vista", "Lamento profundamente el inconveniente").
- Directo y sincero: NO le des la razón automáticamente al usuario. Si una idea es floja, si un giro de guion es predecible o cliché, si una función de código tiene un bug o si una solución está sobrecomplicada al pedo, decíselo de frente con buena onda, explicándole con argumentos claros por qué no convence y qué alternativa mejor se puede probar.
- Humor natural y amigable: toques de ironía sutil o comentarios espontáneos cuando dé el momento, sin transformar cada respuesta en un stand-up ni perder el foco.
- Conversaciones normales: si el usuario te hace una pregunta corta o te habla de algo cotidiano para despejar la cabeza, respondé con soltura y brevedad humana, no como si estuvieras redactando un manual técnico o una tesis académica.

Tus áreas clave de ayuda:
1. El Manga "Ecos":
   - Es el proyecto de manga principal del usuario.
   - Ayudalo a fondo con la historia, guion, arcos de personajes, diálogos genuinos, estructura de viñetas y ritmo de lectura (pacing, páginas dobles, giros que impacten).
   - Sistemas de poder: velá porque las habilidades tengan reglas sólidas, límites estrictos, debilidades lógicas y consecuencias reales.
   - Originalidad: desafiá lo trillado para que "Ecos" tenga identidad propia y no se sienta una copia de fórmulas gastadas.

2. Tecnología y Programación:
   - Código limpio, moderno y funcional (TypeScript, JavaScript, Python, React, APIs, Node, etc.).
   - Debugging al hueso: detectá el error real sin dar vueltas y explicá la solución de forma directa con ejemplos claros.

3. Inteligencia Artificial:
   - Conceptos, prompting estratégico, flujos de trabajo, automatización y herramientas para potenciar sus proyectos.

4. Ayuda con proyectos y aplicaciones:
   - Arquitectura, decisiones de diseño de software, validación de ideas y resolución pragmática de problemas.

5. Conversaciones cotidianas:
   - Cualquier tema del día a día, debatir ideas, películas, anime, música o simplemente charlar un rato para destrabar la cabeza.

Formato y longitud de respuestas (clave para sonar como una persona real conversando):
- Preguntas simples, saludos o charlas casuales: respondé de forma breve, espontánea y directa (una o dos oraciones, al pie, sin discursos ni rodeos).
- Preguntas normales o cotidianas: respondé en 1 a 3 párrafos concisos y enfocados. No conviertas una consulta estándar en un ensayo ni armes listas kilométricas al pedo.
- Temas filosóficos, debates importantes o cuestiones clave de "Ecos": explayate con profundidad cuando el tema realmente lo amerite y sume valor genuino.
- Peticiones explícitas de detalle: si el usuario pide expresamente un desglose largo, un guion paso a paso o un análisis exhaustivo, dale todo el desarrollo que haga falta.
- Cero relleno: no metas información innecesaria solo para que la respuesta parezca más completa. Nunca repitas la pregunta del usuario como intro ("Me preguntás sobre..."), ni expliques obviedades que ya quedaron claras.
- Usá Markdown prolijo cuando organices fragmentos de guion o bloques de código.
- Respuestas directas, con sustancia, ritmo natural y buena onda.`;

// Helper to keep active dialogue window while avoiding heavy token ingestion latency
function optimizeMessageHistory(
  rawMessages: Array<{ role: string; content: string }>,
  maxTurns = 14
) {
  if (!Array.isArray(rawMessages) || rawMessages.length === 0) return [];

  // Take the most recent messages up to maxTurns
  let sliced = rawMessages.slice(-maxTurns);

  // Ensure history slice starts with a 'user' message for valid Gemini role alternating sequence
  const firstUserIdx = sliced.findIndex(
    (m) => m.role === 'user' || (!m.role || (m.role !== 'model' && m.role !== 'assistant'))
  );
  if (firstUserIdx > 0) {
    sliced = sliced.slice(firstUserIdx);
  }

  return sliced.map((m) => ({
    role: m.role === 'model' || m.role === 'assistant' ? 'model' : 'user',
    parts: [{ text: m.content || '' }],
  }));
}

async function main() {
  const app = express();
  const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

  // CORS support for Android Capacitor webview and external clients
  app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
    if (req.method === 'OPTIONS') {
      res.sendStatus(200);
      return;
    }
    next();
  });

  app.use(express.json({ limit: '10mb' }));

  const apiKey = process.env.GEMINI_API_KEY || '';
  const ai = new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });

  // Health check
  app.get('/api/health', (_req: Request, res: Response) => {
    res.json({
      status: 'ok',
      assistant: 'Denji',
      hasApiKey: Boolean(apiKey),
      model: 'gemini-3.8-flash',
    });
  });

  // Download project ZIP with complete android/ folder and GitHub Actions for direct APK compilation
  app.get('/api/download-project-zip', (_req: Request, res: Response) => {
    const zipPath = path.resolve(__dirname, 'public', 'denji-android-project.zip');
    if (fs.existsSync(zipPath)) {
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', 'attachment; filename="denji-android-project.zip"');
      res.download(zipPath, 'denji-android-project.zip');
    } else {
      res.status(404).json({ error: 'El archivo ZIP no está disponible en este momento.' });
    }
  });

  // Chat Streaming Endpoint (SSE) - optimized for low latency and high availability
  app.post('/api/chat/stream', async (req: Request, res: Response) => {
    const { messages, mangaContext } = req.body;

    if (!Array.isArray(messages) || messages.length === 0) {
      res.status(400).json({ error: 'Se requiere un arreglo de mensajes válido.' });
      return;
    }

    if (!process.env.GEMINI_API_KEY) {
      res.status(500).json({
        error: 'No se encontró la variable GEMINI_API_KEY en el entorno del servidor.',
      });
      return;
    }

    // Prepare system instructions with custom project context if provided
    let fullSystemInstruction = DENJI_BASE_SYSTEM_INSTRUCTION;
    if (mangaContext && typeof mangaContext === 'string' && mangaContext.trim()) {
      fullSystemInstruction += `\n\n[CONTEXTO ACTIVO DEL PROYECTO]: ${mangaContext.trim()}`;
    }

    // Format and optimize message history
    const formattedContents = optimizeMessageHistory(messages);

    // Configure SSE headers with zero proxy buffering and immediate TCP transmission
    res.setHeader('Content-Type', 'text/event-stream; charset=utf-8');
    res.setHeader('Cache-Control', 'no-cache, no-transform');
    res.setHeader('Connection', 'keep-alive');
    res.setHeader('X-Accel-Buffering', 'no');
    if (res.socket) {
      res.socket.setNoDelay(true);
    }
    res.flushHeaders?.();

    const candidateModels = ['gemini-3.8-flash', 'gemini-3.1-flash-lite'];
    let streamSucceeded = false;
    let lastError: unknown = null;

    for (const model of candidateModels) {
      if (streamSucceeded) break;

      const maxRetries = 2;
      for (let attempt = 0; attempt <= maxRetries; attempt++) {
        try {
          const config: Record<string, unknown> = {
            systemInstruction: fullSystemInstruction,
            temperature: 0.8,
          };
          if (model === 'gemini-3.8-flash') {
            config.thinkingConfig = { thinkingLevel: ThinkingLevel.LOW };
          }

          const responseStream = await ai.models.generateContentStream({
            model,
            contents: formattedContents,
            config,
          });

          for await (const chunk of responseStream) {
            if (chunk.text) {
              res.write(`data: ${JSON.stringify({ text: chunk.text })}\n\n`);
            }
          }

          res.write('data: [DONE]\n\n');
          res.end();
          streamSucceeded = true;
          break;
        } catch (err: unknown) {
          lastError = err;
          const isQuota =
            err instanceof Error &&
            (err.message.includes('429') || err.message.includes('RESOURCE_EXHAUSTED'));
          if (isQuota) {
            console.warn(`Model ${model} quota reached, falling back to next candidate...`);
            break; // Immediately try next model in candidate list
          }

          const isTransient =
            err instanceof Error &&
            (err.message.includes('503') ||
              err.message.includes('UNAVAILABLE') ||
              err.message.includes('high demand'));

          if (isTransient && attempt < maxRetries) {
            console.warn(`Transient Gemini error on ${model}, retrying attempt ${attempt + 1}...`);
            await new Promise((resolve) => setTimeout(resolve, (attempt + 1) * 1000));
            continue;
          }
          break; // Try next candidate model
        }
      }
    }

    if (!streamSucceeded) {
      console.error('All candidate models failed for streaming:', lastError);
      let errorMessage = 'Che, hubo un problema al procesar la respuesta. Probá mandar de nuevo.';
      if (lastError instanceof Error) {
        if (lastError.message.includes('503') || lastError.message.includes('high demand')) {
          errorMessage = 'Che, el servicio está con alta demanda temporal en este momento. Dale unos segundos y reintentamos.';
        } else if (lastError.message.includes('429')) {
          errorMessage = 'Che, se llegó al límite momentáneo de peticiones. Probá de nuevo en un rato.';
        } else {
          errorMessage = lastError.message;
        }
      }
      res.write(`data: ${JSON.stringify({ error: errorMessage })}\n\n`);
      res.end();
    }
  });

  // Non-streaming fallback endpoint
  app.post('/api/chat', async (req: Request, res: Response) => {
    const { messages, mangaContext } = req.body;

    if (!Array.isArray(messages) || messages.length === 0) {
      res.status(400).json({ error: 'Se requiere un arreglo de mensajes válido.' });
      return;
    }

    if (!process.env.GEMINI_API_KEY) {
      res.status(500).json({
        error: 'No se encontró la variable GEMINI_API_KEY en el servidor.',
      });
      return;
    }

    let fullSystemInstruction = DENJI_BASE_SYSTEM_INSTRUCTION;
    if (mangaContext && typeof mangaContext === 'string' && mangaContext.trim()) {
      fullSystemInstruction += `\n\n[CONTEXTO ACTIVO DEL PROYECTO]: ${mangaContext.trim()}`;
    }

    const formattedContents = optimizeMessageHistory(messages);
    const candidateModels = ['gemini-3.8-flash', 'gemini-3.1-flash-lite'];
    let lastError: unknown = null;

    for (const model of candidateModels) {
      const maxRetries = 2;
      for (let attempt = 0; attempt <= maxRetries; attempt++) {
        try {
          const config: Record<string, unknown> = {
            systemInstruction: fullSystemInstruction,
            temperature: 0.8,
          };
          if (model === 'gemini-3.8-flash') {
            config.thinkingConfig = { thinkingLevel: ThinkingLevel.LOW };
          }

          const response = await ai.models.generateContent({
            model,
            contents: formattedContents,
            config,
          });

          res.json({
            role: 'model',
            content: response.text || '',
          });
          return;
        } catch (err: unknown) {
          lastError = err;
          const isQuota =
            err instanceof Error &&
            (err.message.includes('429') || err.message.includes('RESOURCE_EXHAUSTED'));
          if (isQuota) {
            console.warn(`Model ${model} quota reached, trying next candidate...`);
            break;
          }

          const isTransient =
            err instanceof Error &&
            (err.message.includes('503') ||
              err.message.includes('UNAVAILABLE') ||
              err.message.includes('high demand'));

          if (isTransient && attempt < maxRetries) {
            console.warn(`Transient Gemini error on ${model}, retrying attempt ${attempt + 1}...`);
            await new Promise((resolve) => setTimeout(resolve, (attempt + 1) * 1000));
            continue;
          }
          break;
        }
      }
    }

    console.error('All candidate models failed for /api/chat:', lastError);
    let errorMessage = 'Error al generar respuesta.';
    if (lastError instanceof Error) {
      if (lastError.message.includes('503') || lastError.message.includes('high demand')) {
        errorMessage = 'Che, el servicio está con alta demanda temporal en este momento. Dale unos segundos y reintentá.';
      } else if (lastError.message.includes('429')) {
        errorMessage = 'Che, se llegó al límite momentáneo de peticiones. Probá de nuevo en un rato.';
      } else {
        errorMessage = lastError.message;
      }
    }
    res.status(500).json({ error: errorMessage });
  });

  // Vite Integration
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Denji Assistant Server running on http://0.0.0.0:${PORT}`);
  });
}

main().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
